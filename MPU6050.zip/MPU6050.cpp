#include "Arduino.h"
#include "Wire.h"
#include "MPU6050.h"

MPU6050::MPU6050(bool cs):i2c_addr(cs?0x69:0x68){  
}

void MPU6050::begin(){
  Wire.begin();
  TWBR = 12;
  Wire.beginTransmission(i2c_addr);
  Wire.write(0x6B);
  Wire.write(0x00);
  Wire.endTransmission();
  Wire.beginTransmission(i2c_addr);
  Wire.write(0x1C);
  Wire.write(0x10);
  Wire.endTransmission();
  Wire.beginTransmission(i2c_addr);
  Wire.write(0x1B);
  Wire.write(0x08);
  Wire.endTransmission();
  Wire.beginTransmission(i2c_addr);
  Wire.write(0x1A);
  Wire.write(0x05);
  Wire.endTransmission();
}

void MPU6050::get_data(int16_t acc_data[], int16_t gyro_data[]){
  Wire.beginTransmission(i2c_addr);
  Wire.write(0x3B);
  Wire.endTransmission();
  Wire.requestFrom(i2c_addr, 14);
  while (Wire.available() < 14);
  acc_data[0] = Wire.read() << 8 | Wire.read();
  acc_data[1] = Wire.read() << 8 | Wire.read();
  acc_data[2] = Wire.read() << 8 | Wire.read();
  gyro_data[0] = Wire.read() << 16 | Wire.read();
  gyro_data[1] = Wire.read() << 8 | Wire.read();
  gyro_data[2] = Wire.read() << 8 | Wire.read();
}
