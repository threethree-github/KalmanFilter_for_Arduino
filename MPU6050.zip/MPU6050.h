#ifndef _MPU6050_H
#define _MPU6050_H

class MPU6050{
private:
  int i2c_addr;
public:
  MPU6050(bool cs);
  void begin();
  void get_data(int16_t acc_data[], int16_t gyro_data[]);
};
#endif
